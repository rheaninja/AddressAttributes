<?php
declare(strict_types=1);
namespace Ninja\AddressAttributes\Model;

use Magento\Framework\Model\AbstractModel;

class Attribute extends AbstractModel
{
    protected function _construct()
    {
        $this->_init(\Ninja\AddressAttributes\Model\ResourceModel\Attribute::class);
    }
}
